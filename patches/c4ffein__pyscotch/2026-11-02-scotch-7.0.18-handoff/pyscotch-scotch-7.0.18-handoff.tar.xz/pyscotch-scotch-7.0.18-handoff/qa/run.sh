#!/bin/bash
# QA: build patched trees, then run check/ptcheck/escheck one tree at a time on pristine and patched, 32 and 64 bits
SP=/tmp/claude-0/-home-user-playground/925301e5-494b-5a33-b598-8eaa63dd5c1d/scratchpad; I=$SP/infra18; Q=$SP/qa18
export OMPI_ALLOW_RUN_AS_ROOT=1 OMPI_ALLOW_RUN_AS_ROOT_CONFIRM=1 UBSAN_OPTIONS=print_stacktrace=1
for w in 32 64; do
  t=$Q/patched$w; src=asan; [ $w = 64 ] && src=asan64
  [ -d $t/src ] || { mkdir -p $t && git -C $SP/combine archive comb | tar -x -C $t; }
  cp $I/$src/src/Makefile.inc $t/src/Makefile.inc
  make -C $t/src -j4 scotch ptscotch esmumps ptesmumps > $Q/patched$w-build.log 2>&1; echo "patched$w build exit=$? warnings=$(grep -c 'warning:' $Q/patched$w-build.log)"
  for p in pristine patched; do
    if [ $p = pristine ]; then base=$Q/pristine$w; mkdir -p $base; [ -d $base/src ] || cp -r $I/$src/. $base/; else base=$t; fi
    for s in check ptcheck escheck; do
      make -C $base/src/check realclean >/dev/null 2>&1
      ASAN_OPTIONS=detect_leaks=$([ $s = check ] && echo 1 || echo 0) LD_LIBRARY_PATH=$base/lib flock /tmp/scotch-check.lock timeout 3600 make -k -C $base/src $s > $Q/$p$w-$s.log 2>&1
      echo "$p$w $s exit=$? failed=$(grep -o "\\[Makefile:[0-9]*: check_[a-z0-9_]*\\]" $Q/$p$w-$s.log | sort -u | tr "\\n" " ") sanitizer=$(grep -c 'runtime error\|ERROR: AddressSanitizer\|ERROR: LeakSanitizer' $Q/$p$w-$s.log)"
    done
  done
done
