# Decisions left to the PyScotch maintainer after the 7.0.18 round

Verbatim from each group's SUMMARY.md ("User must decide" sections). Group order as in order.txt. The
cross-group ones are also summarised in HANDOFF.md section 5.

## G01-arch-sub-dist

User must decide: whether 'dist' with crloval 0 should stay loadable (0003 rejects it, as kgraphInit() does in debug mode); whether SCOTCH_archSub()'s contract is "failed Arch is empty" (0001 implements it).

## G02-arch-tleaf-hcub-build

User must decide: whether kgraph_map_rb.c fixes (0008/0009) stay in G02 or move to the RB-mapping group (G12); whether SCOTCH_archHcub(0) should be rejected (0006 does, like 'hcub 0' in files).

## G03-arch-mesh-deco-misc

Could not do: no regression tests (no negative-test precedent in src/check); arch_deco.c:205/211 distance-average overflow left (needs a distance bound decision); PS2-G03-2 only read.

User must decide: whether type-1 size/weight -1 (accepted by a7692fbb) should be rejected (0002 rejects negative sizes via the tree check, keeps weights); whether SCOTCH_archTorus*() rejecting sizes < 1 is acceptable as a behaviour change (it matches the mesh builders).

## G04-strategy-parser

User must decide: COR-13 style (his minimal-parentheses table, our 0005, vs always-parenthesize alt A); whether to print doubles
with '%.17g' (PS2-5); last_resort files will need his release-time regeneration after the grammar commits.


## G05-strategy-tables-api

User must decide: merge order with G24 (both touch hdgraph_order_st.c: G05 0002 adds the else-less default, G24 0002 makes the
STRATNODEEMPTY call return its status); whether 1e30-style ratios must be accepted by the 32-byte builders (API-07).


## G06-threads-context

- PS2-G06-1 still-present -> still-present ran medium -> - (alt PS2-G06-1-a, design decision)
- PS2-G06-2 still-present -> still-present ran low -> 0005
- PS2-G06-3 still-present -> still-present source-read info -> -
- PS2-G06-4 still-present -> still-present ran low -> - (alt PS2-G06-1-a)
- extra PS3-G06-1 (new, low): coretab -1 now binds to CPU 0, outside the mask -> 0003
- extra PS3-G06-2 (new, medium): abort path destroys cond/mutex under waiting slaves, then frees their context (TSan) -> 0002

User decides: PS2-G06-1 semantics (reseed per context vs once per process) before any commit; whether to keep the now-dead
re-check in threadWaitBarrier1 (left as is, harmless).

## G07-common-misc

User must decide: keep our intLoad test as its own commit; whether to also convert the Chaco/HB/MatrixMarket loaders (G14).


## G08-bgraph-gg-gain

User decides: nothing new; the 1-thread vs >=2-thread residual is PS2-G08-2 (G15 0006 / G12 0009).

## G09-bgraph-df-ga-fm

User decides: nothing new.

## G10-mesh-separators

User decides: nothing new.

## G11-mesh-struct-io

User must decide
- PS2-1 (G05's file), PS2-7 (G14's file), PS2-9 (honour the Fortran rank string or document it), PS2-10 (drop the
  prototype or the whole mesh_io.h): unchanged from 7.0.17, alt diffs still apply to v7.0.18.

## G12-overlap-kgraph-rb

User must decide
- Report PS3-G12-1 upstream urgently (7.0.18 regression affecting SCOTCH_graphPartFixed/MapFixed users).
- Message wording: upstream uses "invalid part array"; our remaining patch keeps his wording.

## G13-kgraph-fm-df-bd

User must decide
- Whether to fix PS3-G13-2 (kgraphMapFm leaks on every error path) with a fail: label refactor.
- kgraph_map_bd.c:121 still declares `int *` for unsigned flag macros (extra instance of GRA-16, left as is).

## G14-graph-loaders

User must decide
- PS-API-5: reject duplicate labels in graphCheck (ours) or harden consumers.
- 0009 rejects HB formats with fields wider than 80 characters (none valid); 0005 rejects labels equal to GNUMMAX.
- PS2-G11-mesh-struct-io-7 (graph_io_scot.c unlabeled base) is visible once 0003 is in; left unpatched (behaviour change).

## G15-order-io-seq-misc

User must decide
- PS2-G15-5 (fix the manual or accept unsorted .ord lines), PS2-G15-7 (implement or drop the documented Fortran
  ordering I/O routines), PS2-G15-6 (gotst, tools owner): unchanged from 7.0.17.

## G16-library-seq-api

User must decide: PartDiam convention for disconnected parts (A, ours: components linked by one edge; B,
alt/API-14-b-chain-without-gap.diff: sum of diameters, smaller diff, isolated vertices invisible); whether to send
0007 (dgmap label change "Cmlosum" -> "CommLoad", breaks greps); update the 7 PyScotch edlosum assertions.

## G17-fortran-wrappers

User must decide: series order with G02 0001 (needed to build our 0004) or fold the declaration into 0004;
whether to send 0006/0007 (wrappers for undocumented C routines; vmlotab cannot be NULL from Fortran).

## G18-dgraph-fold-redist

User must decide: whether to send unconditional release-build MPI_Allreduce agreements (0003, 0004, 0006) or ask
the maintainer for his preferred idiom (piggyback on an existing collective, as he did in 484adec3; alt B for redist).

## G19-dgraph-build-induce

User must decide: unconditional release-build agreements in dgraphBuild3 (0002) and the new MPI_Allreduce in
dgraphBuildGrid3D (0001, same pattern as dgraphBuildHcub), and the stricter dgraphCheck (0006) which now rejects
user graphs with edge loads <= 0, out-of-range ends or ends in numbering holes.

## G20-dgraph-io-dmesh

User must decide: PS-DGR-2 / PS2-G20-2 (halo-exchange allocation failures hang every caller: redist, induce,
coarsen, save): unconditional Allreduce in dgraphHaloSync2 (alt A, hot path) vs pre-allocated scratch (alt B).

## G21-dgraph-band-coarsen

User must decide: the unconditional release-build agreements of 0002 (band/grow) and 0008 (coarse arrays,
reverses the maintainer's explicit '#ifdef SCOTCH_DEBUG_DGRAPH1' choice), as in G18/G19.

## G22-bdgraph

User must decide
- DMO-03: keep his strict partial-failure error, or the tolerant twin-consistent alt (debug-only check).
- DMO-19: merge 0006 (MPI exchange for a feature not yet enabled) now, or hold it; 0005 is independent.
- 0004: he chose rename-only; resend the unconditional default case (fixes a release -O2 warning) or drop it.

## G23-vdgraph-dorder

User must decide: DMO-15 empty-or-complete test (alt/DMO-15-B) vs his range test; whether 0006 (G24's
kdgraph_map_rb_part.c) goes with this group; whether to also check putc/fflush in the ordering writers.

## G24-hdgraph

User must decide: merge order with G05 (both edit hdgraph_order_st.c) and with G18 (DMO-08/PS-DMO-4 depend on it); whether to
fix PS2-G24-1/-3 (API-level agreement, dorderSave of a failed ordering).


## G25-metis-graph-part

User must decide: keep the shared _SCOTCH_METIS_V5_PartGraph() restructuring (needed by 0004/0005) vs minimal checks
on top of his two wrappers (option D); ubvec[0] == 1.0: 7.0.18 accepts it (zero tolerance), 0003 rejects it like
values < 1 (MeTiS documents ratios > 1).

## G26-metis-dual-esmumps

User must decide: merge order with G25 (if G25 0004 lands first, switch the two inline option reads in 0001/0002 to
_SCOTCH_METIS_optionGet()) and with G17 0002 (the Fortran dual test is touched by both; trivial 3-way merge).

## G27-seq-tools

## User must decide
- PS2-G27-4 (Tulip ids based) and PS2-G27-8 remain design questions; no patch.

## G28-tools-docs-tests

## User must decide
- CLI-21 0004 (MPI_Abort in libptscotcherrexit) is a behaviour change; PS2-G28-2 / PS2-G28-4 left unpatched.

## G29-cmake-sources-config

## User must decide
- 0007 re-adds two custom targets that 635741dd deliberately removed; alternative (b) avoids them but
  orders two unrelated libraries. BLD-13 floor 3.18 drops older distributions (alt b: 3.14).

## G30-cmake-tests-make-ci

## User must decide
- BLD-03: rotate the token already archived in sonar artifacts; PS2-G30-3 left unpatched.

