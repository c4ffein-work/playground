#!/bin/bash
SP=/tmp/claude-0/-home-user-playground/925301e5-494b-5a33-b598-8eaa63dd5c1d/scratchpad
cd $SP/combine; n=0; START=${1:-1}
[ "$START" = 1 ] && git checkout -q -B comb v7.0.18
while read p; do n=$((n+1)); [ $n -lt $START ] && continue
  if git am -q -3 "$p" >/tmp/am.log 2>&1; then continue; fi
  git am --abort 2>/dev/null
  if git apply -R --check "$p" 2>/dev/null; then echo "#$n ALREADY-APPLIED (duplicate) $p"; continue; fi
  old=$(grep -F "$p " $SP/resolved_map.txt | awk '{print $2}')
  if [ -n "$old" ] && git cherry-pick "$old" >/tmp/cp.log 2>&1; then echo "#$n used earlier resolution $p"; continue; fi
  git cherry-pick --abort 2>/dev/null
  echo "STOP at #$n $p"; exit 1
done < $SP/seq2.txt; echo "ALL DONE: $(git rev-list --count v7.0.18..comb) commits"
