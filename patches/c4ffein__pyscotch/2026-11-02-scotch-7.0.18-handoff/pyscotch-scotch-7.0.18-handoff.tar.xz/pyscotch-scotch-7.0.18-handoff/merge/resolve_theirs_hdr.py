import re,sys
p=sys.argv[1]; s=open(p).read()
def r(m):
    o,t=m.group(1),m.group(2)
    assert "nov 2026" in t or "oct 2026" in t, (o,t)
    return t
s2=re.sub(r"<<<<<<< HEAD\n(.*?)=======\n(.*?)>>>>>>> [^\n]*\n",r,s,flags=re.S)
assert "<<<<<<<" not in s2; open(p,"w").write(s2)
