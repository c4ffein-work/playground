# Combining the 30 group series on v7.0.18: what needed a human

The agents rebased each group onto bare v7.0.18. Applying all groups in `order.txt` order (alphabetical, G10
last) with `git am -3` left 12 conflicts at first. Below is each one and how it was resolved. The resolved
commits were written back to the group's `patches/` folder in the repository; the agent's original is in
`pre-merge/<group>/` here. `replay.sh` re-runs the whole sequence (`apply-sequence.txt`) and falls back to a
recorded resolution where a patch conflicts.

## Duplicates dropped (`dropped/<group>/`)

| Dropped | Kept | Why |
|---|---|---|
| G02 0008 (size fixed-vertex merge hash table) | G12 0002 | Same root cause, same hunk in kgraph_map_rb.c (22c9c42e regression). G12 owns the file and its commit carries a regression test. |
| G25 0007 (same) | G12 0002 | Same as above. PS3-G02-4 and PS3-G25-1 merged into PS3-G12-1. |
| G02 0009 (hash table leak on 6f734966's error return) | G12 0004 | G12's also covers the two debug-mode returns and updates `domnnbr`. PS3-G02-5 merged into PS3-G12-2. |
| G26 0009 (negative degrees in graph/mesh loaders) | G14 0005 + G11 0010 | After those two, nothing of G26 0009 remains (degrees are rejected at read time). PS3-G26-1 points at them. |
| G25 0001 (free proper array on invalid target weight in `archCmpltwArchBuild2()`) | G02 0007 | Identical change. PS2-G25-1 points at G02 0007. |

## Conflicts resolved by hand

- **G05 0003** (`src/check/test_strat_seq.c`): G04 and G05 both append a test block at the end of `main`.
  Both kept, G04's first.
- **G12 0006** (`src/check/CMakeLists.txt`): G12's `test_scotch_graph_part_ovl_3` line goes right after
  `_ovl_2`, then G11's `test_scotch_mesh_geom` block.
- **G16 0008** (`src/check/CMakeLists.txt`): header date only; an earlier patch still had `13 oct 2026`.
  Took `02 nov 2026`.
- **G26 0001/0002** (`metis_graph_part_dual.c`, `test_libmetis_dual_f.f90.in`): G25 0004 introduced the shared
  option helper `_SCOTCH_METIS_optionGet()` and range-checks the numbering option; G26 was written without it.
  Kept G25's helper and check, added G26's null-array handling (`velotab`/`vsiztab`) and its second Fortran test
  block after G25's partition-range checks.
- **G30 0002** (`src/libscotch/Makefile`, "could not build fake ancestor"): another group had fixed the
  `library_arch_dom` source name, which shifted context. The three rejected dependency hunks were applied by hand.
- **G30 0014** (`test_scotch_mesh_build_f.f90.in`): G17 0005 adds the same mesh exit call with the same subject,
  but without `##SCOTCH_NAME_SUFFIX`; G30's suffix conversion comes later in the order and does not see it. G17's
  commit kept; G30 0014 rewritten to "Use the name suffix in the mesh exit call of the Fortran mesh build test".
- **G10 0002** (`src/check/Makefile`): test-list lines for `test_scotch_mesh_order` / `check_scotch_mesh_order`
  placed after the `mesh_graph` entries (the lists had grown in between).

## Found by QA, not by git: a semantic conflict

G28 0008 changes the signature of `checkMap()` in `src/check/test_scotch_graph_map.c` to
`(archptr, vertnbr, parttab, parftab)`. G12 0002, earlier in the order, adds two calls with the old signature
`(vertnbr, parttab, partnbr, flagval)`. Both apply cleanly; the result compiles with 6 `-Wint-conversion` warnings
and `check_scotch_graph_map` segfaults on both Gnum sizes. Fix folded into G28 0008: the two calls become
`checkMap (&fixarchdat, vertnbr, parttab, NULL)` (`fixarchdat` is a complete graph with `vertnbr` terminals, so
this is the same range check).

**Lesson:** after combining, grep the `check` build output for warnings. The library builds are warning-free by
construction, but test programs are compiled during `make check` and their warnings are easy to miss.

## Other merge notes

- 28 patch files were rewritten in total. Most only differ in context lines, because they were 3-way applied on
  top of other groups. Their originals are in `pre-merge/`.
- Group order: alphabetical with G10 last. G15's 0006 must precede G10, which alphabetical order already ensures.
- Some kits and raw audits keep scratch paths (`/tmp/claude-0/...`), as the 7.0.17 ones keep `/tmp/claude-1000/...`;
  `findings.json` is scrubbed.
