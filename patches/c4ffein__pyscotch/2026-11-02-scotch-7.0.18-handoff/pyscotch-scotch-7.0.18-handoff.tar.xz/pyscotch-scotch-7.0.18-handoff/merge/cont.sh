#!/bin/bash
# usage: cont.sh START  -- apply seq.txt from line START, stop at first failure
SP=/tmp/claude-0/-home-user-playground/925301e5-494b-5a33-b598-8eaa63dd5c1d/scratchpad
cd $SP/combine; n=0
while read p; do n=$((n+1)); [ $n -lt $1 ] && continue
  if ! git am -q -3 "$p" >/tmp/am.log 2>&1; then echo "STOP at #$n $p"; tail -3 /tmp/am.log; git status --short | grep -v '^??' | grep -v '^M ' | head; exit 1; fi
done < $SP/seq.txt; echo ALL DONE
