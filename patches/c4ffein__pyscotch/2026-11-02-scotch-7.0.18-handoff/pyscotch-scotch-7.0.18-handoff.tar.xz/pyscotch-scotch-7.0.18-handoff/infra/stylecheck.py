#!/usr/bin/env python3
"""Cheap mechanical checks for the Scotch coding style (maintainer guide, sections 2.1-2.3).

usage: python3 -I stylecheck.py FILE...      (only checks lines you are likely to have written;
run it on the whole file and ignore pre-existing hits that are not in your hunks)
"""
import re
import sys

RX_CALL = re.compile(r"\b(if|for|while|switch|return|sizeof)\(")
RX_FUNC = re.compile(r"\b([A-Za-z_][A-Za-z0-9_]*)\((?!\))")  # name( with no space
RX_RET = re.compile(r"\breturn\s+[^;(\s][^;]*;")

KEYWORDS = {"if", "for", "while", "switch", "return", "sizeof", "defined"}


def check(path):
    hits = []
    try:
        lines = open(path, encoding="utf-8", errors="replace").read().split("\n")
    except OSError as e:
        return [f"{path}: {e}"]
    in_block = False
    for n, line in enumerate(lines, 1):
        if "\t" in line:
            hits.append(f"{path}:{n}: tab character")
        if line != line.rstrip():
            hits.append(f"{path}:{n}: trailing whitespace")
        s = line.strip()
        if s.startswith("/*") or s.startswith("**") or s.startswith("*/") or in_block:
            if "/*" in s and "*/" not in s:
                in_block = True
            if "*/" in s:
                in_block = False
            continue
        if "//" in line and '"' not in line.split("//")[0]:
            hits.append(f"{path}:{n}: C++ comment")
        if RX_CALL.search(line):
            hits.append(f"{path}:{n}: keyword/call without a space before '('")
        m = RX_RET.search(line)
        if m and not re.search(r"\breturn\s*\(", line):
            hits.append(f"{path}:{n}: return without parentheses")
        if re.search(r"\}\s*else\b", line):
            hits.append(f"{path}:{n}: 'else' must start its own line after '}}'")
        if re.search(r"\(\s+\S|\S\s+\)", line) and "/*" not in line and not re.search(r"for \(.*;\s*\)", line):
            # Allow alignment spaces inside parentheses only in continuation lines
            if not line.startswith("  " * 2) or line.lstrip().startswith(("&", "*", "(")):
                pass
        # code line comments: must start at col >= 50, or one space after code when code is longer
        i = line.find("/*")
        if i > 0 and not s.startswith("#"):
            code = line[:i].rstrip()
            if len(code) + 1 < 50 and i != 50:
                hits.append(f"{path}:{n}: line comment starts at column {i}, expected 50")
            elif len(code) + 1 >= 50 and i != len(code) + 1:
                hits.append(f"{path}:{n}: line comment should start one space after the code")
            txt = line[i + 2 :].strip().lstrip("+").strip()
            if txt and txt[0].islower():
                hits.append(f"{path}:{n}: comment text should start with an upper-case letter")
            if txt.rstrip("+*/ ").endswith("."):
                hits.append(f"{path}:{n}: line comment should not end with a period")
    return hits


if __name__ == "__main__":
    bad = 0
    for p in sys.argv[1:]:
        for h in check(p):
            print(h)
            bad += 1
    sys.exit(1 if bad else 0)
