# BRIEF (7.0.18 round): re-verify one group of Scotch findings on 7.0.18, review upstream's fixes, rebase our patches

## Context
PyScotch is a Python binding for Scotch and also an independent test bench for it. For Scotch 7.0.17 we audited 350
findings in 30 GROUPS of findings that share source files: the 192 leads of R. Perry's review, plus 158 defects we found
ourselves (`PS-*` and `PS2-<group>-<n>`). We wrote 240 maintainer-grade commits on v7.0.17. The results are in
`PYS/upstream/reports/7.0.17/` and the reproducer kits are in `PYS/upstream/repro/<group>/<id>/`.

Scotch 7.0.18 shipped on 31 Oct 2026. It has 77 non-style commits; most are the maintainer's (François Pellegrini) own
fixes for the same findings, tagged `[report R. Perry]`. Only ONE of our 240 commits was taken verbatim
(`dorderCblkDist` negative return). The rest of his fixes are his own versions, so most of our patches now conflict.

Your job, for each group you own:
1. Give every item its **status in 7.0.18**, verified by running it where possible.
2. **Review every upstream 7.0.18 fix** that touches the group. This is the most important part: the user asked us
   to "check everything is right with every bug fix". For each fix, answer these questions. Is it correct? Is it
   complete: all the instances we listed (`extra_instances`), the twins (sequential/distributed, METIS v3/v5,
   Fortran wrapper), 32- and 64-bit `Gnum`, error paths? Does it introduce a new bug (leak, double free, wrong error
   code, collective mismatch, behaviour change)? How does it compare with our 7.0.17 patch: what did ours do that
   his does not (a test, a twin, a removed dead field), and does his do something better than ours?
3. **Rebase our patches onto v7.0.18.**
   - Drop what upstream fixed completely.
   - Shrink what it fixed partly to the remainder, e.g. the missing twin or the regression test.
   - Re-apply the rest (most apply unchanged, or with `git am -3`).
   - Write new commits for any defect that upstream's fixes introduced.

The quality bar is unchanged: the patches must be as good as what the maintainer would have done himself, or better.
Read `INFRA/STYLE.md`, with two changes for this round:
- Header `to :` dates are bumped to `2 nov 2026`.
- The style reference is now `INFRA/upstream_7.0.17_to_7.0.18.patch`: his 77 fixes for this very review. Copy his
  habits.

Leads are leads. Our own 7.0.17 audit is a set of CLAIMS that you now re-check. "inconclusive" with a precise reason is
a fine status; a guess is not. Do not spawn sub-agents. This job is long; thoroughness beats speed.

## Paths
```
INFRA=/tmp/claude-0/-home-user-playground/925301e5-494b-5a33-b598-8eaa63dd5c1d/scratchpad/infra18   (read-only)
WORKROOT=/tmp/claude-0/-home-user-playground/925301e5-494b-5a33-b598-8eaa63dd5c1d/scratchpad/work18
WORK=$WORKROOT/<GROUP>   (yours; create it)
PYS=/home/user/playground/clones/pyscotch        (read-only: never edit, never run git commands that change state)
```
Never `make` inside INFRA. Run Python as `python3 -I`. The container runs as root: export
`OMPI_ALLOW_RUN_AS_ROOT=1 OMPI_ALLOW_RUN_AS_ROOT_CONFIRM=1` before `mpirun`. Machine: 4 cores, shared with 7 other
agents. Use `make -j3`, and delete build trees you no longer need.

INFRA contents:
- `groups/<GROUP>.json`: your items. Each one is the full 7.0.17 finding: status, evidence, location in 7.0.17,
  fix options, patch files, `repro` kit (`PYS/upstream/repro/<repro>/`), and `also` views from other groups. Each
  group file also lists the files the group's patches touch, the group's 7.0.17 patches
  (`PYS/upstream/reports/7.0.17/patches/<GROUP>/`), and the upstream 7.0.17..7.0.18 commits that touch those files.
- `v7.0.18/`: pristine 7.0.18 source tree.
- `scotch.git/`: clone at v7.0.18, with tags v7.0.16, v7.0.17 and v7.0.18. Branch `combined` is our 240-commit 7.0.17
  series on v7.0.17; match commits by `git patch-id`, not by hash. Clone it; never commit in it.
- `asan/`, `asan64/`: ASan+UBSan `-O0 -g` builds of PRISTINE 7.0.18, 32-bit and 64-bit `Gnum` (libscotch,
  libptscotch, esmumps, metis v3/v5, parmetis v3; `bin/`, `lib/`, `include/`, built in `src/`). Copy them; never
  `make` in them. Both build with 0 warnings.
- `upstream_7.0.17_to_7.0.18.patch`: every upstream commit with its diff (`git -C <clone> log -p v7.0.17..v7.0.18`).
- `scotch_maint7.0.txt`: the maintainer's guide. Sections 2 and 3 are mandatory.
- `STYLE.md`, `stylecheck.py`: our patch checklist and mechanical checker.

## Setup (per group)
```
GROUP=<GROUP>; INFRA=...; WORK=$WORKROOT/$GROUP; mkdir -p $WORK/patches $WORK/alt $WORK/repro
git clone -q --shared $INFRA/scotch.git $WORK/scotch && git -C $WORK/scotch checkout -q -b $GROUP v7.0.18
git -C $WORK/scotch config user.name PyScotch; git -C $WORK/scotch config user.email pyscotch@noreply.invalid
git -C $WORK/scotch am -3 $PYS/upstream/reports/7.0.17/patches/$GROUP/*.patch   # see what still applies; resolve or skip one by one
cp -r $INFRA/asan $WORK/build      # patched 32-bit build tree; mirror sources: cp -r $WORK/scotch/src/. $WORK/build/src/
```
- Base each group on bare v7.0.18. If one of your patches needs context that another group's patch provided in
  7.0.17, rebase it onto bare context and say so in SUMMARY.md.
- If you own several groups, keep one branch per group, so that the patches stay in per-group folders.
- Rebuild: `rm -f $WORK/build/lib/libscotch.so $WORK/build/lib/libptscotch.so $WORK/build/src/libscotch/lib*.so`
  then `make -C $WORK/build/src -j3 scotch ptscotch`. The link rule uses `$?`, so a stale `.so` relinks only the
  changed objects. Then `grep -c "warning:"` must give 0.
- For the 64-bit tree, do the same from `$INFRA/asan64` (its Makefile.inc already has `-DINTSIZE64 -DIDXSIZE64`).
- Check targets and their exact `make` lines: see `$INFRA/v7.0.18/src/check/Makefile`; the 7.0.17 brief used
  `make -C $WORK/build/src/check CC=gcc CCD=gcc SCOTCHLIBS="-lscotch -lscotcherr" METISLIB="-lscotchmetis" check_<x>`,
  plus the `CC=mpicc CCD=mpicc ... -DSCOTCH_PTSCOTCH -lptscotch` form for PT-Scotch targets.
- **Scotch's check suite writes to a shared `/tmp`**, so concurrent suites race and fail falsely. Wrap EVERY check
  run as `flock /tmp/scotch-check.lock make ...`.
- MPI drivers need `MPI_Init_thread(MPI_THREAD_MULTIPLE)` with threaded Scotch; run them as
  `ASAN_OPTIONS=detect_leaks=0 timeout 60 mpirun --oversubscribe -np 3 ...`.

## For every item
1. Find it in 7.0.18. Was it touched by `git log -p v7.0.17..v7.0.18 -- <file>`? By which commit, doing what?
2. Run the reproducer kit (`PYS/upstream/repro/<repro>/`; its README has the commands) against `$INFRA/asan` and,
   where it matters, `$INFRA/asan64`. Record the exact command and the first lines of output. Kits refer to
   7.0.17-era paths: copy the kit into `$WORK/repro/<ID>/` and adapt it there. If you change a kit, keep a README.
3. Status in 7.0.18: `still-present | fixed | partially-fixed | not-a-bug | inconclusive`.
   - `fixed` means completely fixed (verified by running when possible).
   - `partially-fixed` lists the remaining instances in `extra_instances`.
   - An item that was `fixed` or `not-a-bug` in 7.0.17 only needs a quick check that 7.0.18 did not regress it.
4. Method, strict:
   - `ran`: you exercised the claim against 7.0.18.
   - `partly-run`: say in `read_only` which part you only read.
   - `source-read`: say why in `why_not_run`.
   Prefer running. An `LD_PRELOAD` malloc that fails on the N-th call settles most allocation-failure items.
5. Upstream fix review (step 2 of the job), recorded in `upstream_fix_review` (see Output).
6. Patch: the rebased (or new, or shrunk) commit, per STYLE.md, with these checks:
   - 0 warnings on the 32-bit and 64-bit trees.
   - The reproducer passes.
   - The relevant `check_*` targets pass (under flock).
   - `stylecheck.py` and `git diff --check` are clean.
   - Exported with `git -C $WORK/scotch format-patch -o $WORK/patches v7.0.18`.
   - Proven with `git am` on a fresh `git clone --shared $INFRA/scotch.git`.
   Keep the 7.0.17 subject line when the commit is the same fix, so history lines up. Keep alternative diffs in
   `$WORK/alt/` only when the options changed; otherwise just repeat the 7.0.17 `fix_options`, with
   `diff_file: ""` for diffs that no longer apply.
7. Variant hunt, quickly, on the code that upstream just changed: the same pattern elsewhere in the tree.

## Output (strict; validate every JSON with `python3 -I -c 'import json,sys;json.load(open(sys.argv[1]))' FILE`)
`$WORK/audit.json`: a JSON array with one object per item of the group (every id or local_id in `items`, in that
order), with exactly these keys:
```
id (the item's id, or its local_id for PS-*/PS2-* items), our_title (<= 14 words, your wording, as seen in 7.0.18),
status, method, ran, read_only, why_not_run, severity, severity_note,
location_7_0_18 (file:line in 7.0.18), evidence (quoted 7.0.18 lines),
upstream_change (7.0.18 commit hash + one line, or ""),
upstream_fix_review: {commit, verdict: correct | incomplete | wrong | unrelated | "", details (specific: what is
                      right, what is missing, what breaks, with file:line), compared_with_ours (what our 7.0.17 patch did
                      differently; which is better and why)}   ({} if upstream did not touch the item),
review_accuracy (carry over from 7.0.17 unless you have new information), first_pass_critique (carry over),
extra_instances: [ {location, quote, covered_by_patch: bool} ],
fix_options: [ {label, summary, diff_file, tested, tradeoffs, preferred: bool, maintainer_fit} ],
patch_files: [ "$WORK/patches/NNNN-....patch", ... ],
cleanup_done, test_added, docs_updated, needs, needs_note,
notes (include "7.0.17 status: X -> 7.0.18 status: Y" and why it changed)
```
`$WORK/extra.json`: an array of NEW defects not already in any group, ids `PS3-<Gnn>-<n>` (e.g. `PS3-G16-1`). This is
where a bug introduced by an upstream 7.0.18 fix goes. Same shape as in 7.0.17:
`{local_id, our_title, severity, status, method, ran, read_only, why_not_run, location_7_0_18, evidence,
related_ids, fix_options, patch_files, upstream_fix_review}`. Use an empty array if there are none.

`$WORK/patches/*.patch`: the series on v7.0.18. `$WORK/alt/*.diff`: any new alternatives. `$WORK/repro/<ID>/`:
adapted kits.

`$WORK/SUMMARY.md` (<= 45 lines) must contain:
- one line per id: `ID 7.0.17-status -> 7.0.18-status method severity -> patch or '-'`;
- a table of every upstream commit you reviewed, with its verdict;
- the three most important facts;
- what you could not do;
- what the user must decide.

Your final message: at most 15 lines, the same content as the head of SUMMARY.md, and the path of each group's WORK.
