# The 7.0.18 round: every agent launch and every message sent to an agent, verbatim

8 agents (general-purpose subagents of one session), launched together, each following `infra/BRIEF18.md`.
Paths in the prompts are the original session's scratch paths; `INFRA` = `infra/` in this archive, `WORKROOT` = the
per-group work dirs (their deliverables are in the PyScotch repo under `upstream/reports/7.0.18/groups/` and
`upstream/repro/`). Each agent took 350k-600k tokens and 55-95 minutes; the round as a whole about 4M agent tokens.

## Launch 1: arch groups (G01, G02, G03)

```
You are one of 8 agents re-auditing Scotch findings on the new 7.0.18 release for PyScotch. Read and follow /tmp/claude-0/-home-user-playground/925301e5-494b-5a33-b598-8eaa63dd5c1d/scratchpad/infra18/BRIEF18.md exactly (it has paths, setup, method and the strict output format). Then read INFRA/STYLE.md and sections 2-3 of INFRA/scotch_maint7.0.txt.

Your groups, in this order: G01-arch-sub-dist, G02-arch-tleaf-hcub-build, G03-arch-mesh-deco-misc (items in INFRA/groups/<GROUP>.json). One WORK dir per group under WORKROOT.

Group notes: the target-architecture code got the largest share of the maintainer's 7.0.18 work: ecaf094e (sub-architecture loading/building "more robust"), cdee46d9 (alternate matching passes in archCmpltMatchMate, our COR-27 patch had the same title), d4b6f997 ("complete arch_dist.c", our COR-05 design question: own vs reject the inner Arch), 18911e4f (tleaf size overflow), 22c9c42e (hash table never full), 3df345a8 (mesh/torus size overflow), 29c96822 (tighter hcub dimension bound), 6f734966 (terminal domain error codes), a7692fbb (deco loading), 09cf49de (error return codes), 858ea2bc (dummysizes default file names), 611f39c3 (macro parameter names). For each, compare closely against our 7.0.17 patch for the same finding (e.g. our G01 0001/0003 ownership protocol, our 0005 single-terminal sub-arch fix PS2-G01-arch-sub-dist-1, which upstream may not have taken): which loader paths still leak or crash under malformed files and malloc-failure injection, did he cover cmpltw/cmpltws, ltleaf, 64-bit shifts. Patch 0005 of G01 touches arch_deco2_build.c, which G03 also patches: keep the two groups' series apply-compatible (G01 before G03) and say how in SUMMARY.md.

Final message: at most 15 lines per the brief, plus the WORK paths.
```

## Launch 2: strategy / common groups (G04, G05, G07, G24)

```
You are one of 8 agents re-auditing Scotch findings on the new 7.0.18 release for PyScotch. Read and follow /tmp/claude-0/-home-user-playground/925301e5-494b-5a33-b598-8eaa63dd5c1d/scratchpad/infra18/BRIEF18.md exactly (it has paths, setup, method and the strict output format). Then read INFRA/STYLE.md and sections 2-3 of INFRA/scotch_maint7.0.txt.

Your groups, in this order: G04-strategy-parser, G05-strategy-tables-api, G07-common-misc, G24-hdgraph (items in INFRA/groups/<GROUP>.json). One WORK dir per group under WORKROOT.

Group notes: upstream 7.0.18 commits to review: 7a2e069c (logic operator), 088a1279 (display of strategy tests with operator priorities), c778efa6 (error return codes in the parser), 13e4dee6 (strategy-string evaluation protected against modulus by zero), 075a77a6 (parameter type), 8609a5cb (default ordering strategy for an empty `else`), da4af29e (memory allocation check, hdgraph), and in G07 ff9d5a54 "Make integer loading more robust [report Z. Li]", which is the maintainer's answer to COR-15 (intLoad wraps on overflow). That one matters most: every loader's range check (graph, arch, mesh) depends on intLoad's overflow semantics. Verify on both Gnum sizes with digit-string fuzzing and values like 4294967298 and INT64 overflow; check the twins (64-bit variant, sscanf/strtol paths in tools and library_*.c); check that the failure semantics match what all callers test; measure the cost on a large .grf load if he made the check unconditional. For the parser items (COR-01 PARAMVAL NULL-deref, empty scalar value f{move=}), check whether 7.0.18's parser changes touched them; our 7.0.17 G04 patches used a typed <SAVE> mid-rule value with a %destructor: re-run the mutation fuzzer from the repro kit (PYS/upstream/repro/G04-strategy-parser/common/) pristine vs patched on 7.0.18. Also note 635741dd ("parallel build with older Bison versions") touches parser build rules: check our parser patches still build with the bison in this container.

Final message: at most 15 lines per the brief, plus the WORK paths.
```

## Launch 3: threads / bgraph groups (G06, G08, G09, G10)

```
You are one of 8 agents re-auditing Scotch findings on the new 7.0.18 release for PyScotch. Read and follow /tmp/claude-0/-home-user-playground/925301e5-494b-5a33-b598-8eaa63dd5c1d/scratchpad/infra18/BRIEF18.md exactly (it has paths, setup, method and the strict output format). Then read INFRA/STYLE.md and sections 2-3 of INFRA/scotch_maint7.0.txt.

Your groups, in this order: G06-threads-context, G08-bgraph-gg-gain, G09-bgraph-df-ga-fm, G10-mesh-separators (items in INFRA/groups/<GROUP>.json). One WORK dir per group under WORKROOT. G10 must apply LAST in the combined series (it was rebased onto all the others for 7.0.17); keep it apply-compatible.

Group notes:
- G06: upstream 7.0.18 reworked thread start-up and affinity: 86559b85 (abort cleanly when the thread system cannot start, our COR-09: pthread_create failure hung in a barrier sized for the original count, desctab leaked), e122a7c5 (thread number 0, our COR-10), 6eb0aca3 (set affinity mask when importing threads, our COR-11), 52dcf602 (core assignment always uses affinity when available, our COR-24). Review each one hard: use an LD_PRELOAD pthread_create that fails on the N-th call, SCOTCH_PTHREAD_NUMBER=0, taskset, and a ThreadSanitizer build (-O1 -g -fsanitize=thread, built from a copy of INFRA/v7.0.18 with its own Makefile.inc) for the barrier changes. Also re-judge PS2-G08-2 (context split under the deterministic option) and PS2-G06-1 (never-read fixed-seed option).
- G08: bgraph_bipart_gg.c and gain.c are UNCHANGED between 7.0.17 and 7.0.18, so SEP-13 (worker-PRNG seeding race, SCOTCH_DETERMINISTIC ignored) should still be present. PyScotch's own gate already confirmed this: on pristine 7.0.18, the `h` strategy with 4 threads gave 5 distinct partitions over 12 fresh runs. With PYS/pyscotch/_scotch_patches/scotch-7.0.18-bgraph-bipart-gg-determinism.patch, the gate passes. Re-confirm with TSan (gpart, 4 threads) and confirm that our G08 7.0.17 series (the maintainer-grade version of that fix) still applies and passes. This is the finding blocking PyScotch's release, so be precise. Also cover PS-SEP-3 (gainLinkDummy race).
- G09/G10: no upstream source change touched them (only build files via 635741dd/0d878bdd); all their 7.0.17 patches apply. Re-run the kits on 7.0.18 to confirm the status, rebase (format-patch on v7.0.18), and spend your remaining effort on G06/G08.

Final message: at most 15 lines per the brief, plus the WORK paths.
```

## Launch 4: mesh / kgraph / loaders (G11-G15)

```
You are one of 8 agents re-auditing Scotch findings on the new 7.0.18 release for PyScotch. Read and follow /tmp/claude-0/-home-user-playground/925301e5-494b-5a33-b598-8eaa63dd5c1d/scratchpad/infra18/BRIEF18.md exactly (it has paths, setup, method and the strict output format). Then read INFRA/STYLE.md and sections 2-3 of INFRA/scotch_maint7.0.txt.

Your groups, in this order: G11-mesh-struct-io, G12-overlap-kgraph-rb, G13-kgraph-fm-df-bd, G14-graph-loaders, G15-order-io-seq-misc (items in INFRA/groups/<GROUP>.json). One WORK dir per group under WORKROOT.

Group notes:
- G11, G15: no upstream source fix touched them (G15 only a doc commit, 38006ee5); their patches apply. Re-run the kits on 7.0.18, rebase, and move on.
- G12: review a09f3249 (connected components, distances and diameters), 9e015dfe (mapping distance from the proper domain), f2633428 (return after allocation failure in SCOTCH_graphPartOvlView), 22c9c42e (hash table never full), 6f734966 (terminal domain error codes). Note: a09f3249/9e015dfe/f2633428 also touch G16's library files; G16's agent reviews the library side, you review the kgraph/overlap side. Do not patch library_*.c files G16 owns; report in SUMMARY.md.
- G13: 219040c8 (bbalglbval/bbalval management, shared with G22 bdgraph), 25322c9a (error return codes).
- G14: 9c51d9df "edge count overflow check to graph loading [report Z. Li]", 45a4de85 "Robustify string processing", 0ef275a0 (Harwell-Boeing loader sanity check). Fuzz the loaders (.grf, Chaco, MatrixMarket, HB, SCOTCH_graphGeomLoad*) on both Gnum sizes against pristine 7.0.18 ASan, with and without our rebased series. Our 7.0.17 G14 patches added range checks that assumed intLoad semantics; G07 (another agent) is reviewing intLoad's own 7.0.18 change (ff9d5a54). Read $WORKROOT/G07-common-misc/SUMMARY.md if it exists by then, and do not patch common_integer.c.

Final message: at most 15 lines per the brief, plus the WORK paths.
```

## Launch 5: library / Fortran / METIS (G16, G17, G25, G26)

```
You are one of 8 agents re-auditing Scotch findings on the new 7.0.18 release for PyScotch. Read and follow /tmp/claude-0/-home-user-playground/925301e5-494b-5a33-b598-8eaa63dd5c1d/scratchpad/infra18/BRIEF18.md exactly (it has paths, setup, method and the strict output format). Then read INFRA/STYLE.md and sections 2-3 of INFRA/scotch_maint7.0.txt.

Your groups, in this order: G16-library-seq-api, G17-fortran-wrappers, G25-metis-graph-part, G26-metis-dual-esmumps (items in INFRA/groups/<GROUP>.json). One WORK dir per group under WORKROOT.

Group notes:
- G16 (9 upstream commits): 199fa861 (do not read past array end), 5a711ca5 (weighted edge load sum computed like the unweighted one; this is the "edge-load sum convention" open decision, and PyScotch's own tests pin printed numbers, so state exactly which outputs change), 27f4193c (distributed mapping delta from the proper values), a09f3249 (connected components/distances/diameters), 9e015dfe (mapping distance from the proper domain), f2633428 (return after allocation failure in SCOTCH_graphPartOvlView), 38006ee5 (SCOTCH_graphPartOvlView documented). Our API-* items (e.g. API-21 tabload, API-14, API-16 remap) have kits in PYS/upstream/repro/G16-library-seq-api/.
- G17: 48efddda (proper integer type for a returned value), bca5f63b (add error return parameter: an ABI change in a Fortran wrapper? check what callers break), 06f9d09b (proper Fortran wrapper name), and f32c0cff20 "Add missing graphpartovlview() Fortran wrapper", which touches no group file: review it too (all four name-mangling variants, the argument order against the C routine, and the library_f.h / scotchf.h declarations). Also hunt for other exported routines without a Fortran twin in 7.0.18.
- G25: b72baf20 (convert from MeTiS imbalance ratios to Scotch imbalance ratios) and ac868d85 (NULL ubvec in METIS_V5_PartGraphKway). Check the v3 twin, PartGraphRecursive, and ParMETIS (libscotchmetis/parmetis_*), and the exact ratio arithmetic on edge cases (ubvec = 1.0, ncon > 1, 1.001).
- G26: the 9c51d9df/45a4de85 loader changes as seen from the dual-graph and esMUMPS side.

Final message: at most 15 lines per the brief, plus the WORK paths.
```

## Launch 6: dgraph groups (G18-G21)

```
You are one of 8 agents re-auditing Scotch findings on the new 7.0.18 release for PyScotch. Read and follow /tmp/claude-0/-home-user-playground/925301e5-494b-5a33-b598-8eaa63dd5c1d/scratchpad/infra18/BRIEF18.md exactly (it has paths, setup, method and the strict output format). Then read INFRA/STYLE.md and sections 2-3 of INFRA/scotch_maint7.0.txt.

Your groups, in this order: G18-dgraph-fold-redist, G19-dgraph-build-induce, G20-dgraph-io-dmesh, G21-dgraph-band-coarsen (items in INFRA/groups/<GROUP>.json). One WORK dir per group under WORKROOT.

Group notes (all PT-Scotch: use mpirun --oversubscribe -np 2..4 with 60 s timeouts; drivers must use MPI_Init_thread(MPI_THREAD_MULTIPLE); a per-rank LD_PRELOAD malloc-failure shim exists in the 7.0.17 kits under PYS/upstream/repro/G18-dgraph-fold-redist/ or G19/common; reuse it):
- G18: 3a10af93 (set baseval early to allow early freeing), 0e79c872 (typo). Also confirm the dgraphFoldComm "keeps all its vertices" fix (7e17084b, in 7.0.17) still holds.
- G19: 484adec3 (out-of-memory if the hash table cannot be resized), b08bc63e (read the proper error flag), b626b1b8 (base the end of a loop), 4a56ae3f (prevent double free on error), 79a50459 (proper array cells for error return codes).
- G20: e1cfdb64 (free the based array in all cases), 372a93ab (memory leak at allocation and freeing), 42e2df84 (proper error flag), 45a4de85 (string processing), 484adec3.
- G21: 50bf0173 (proper array cells for debug computations), 0536da09 (memcpy with a NULL source in SCOTCH_dgraphCoarsen).
For every error-path fix: is the error now agreed COLLECTIVELY across ranks before the next collective, or does one rank return while the others wait (the 7.0.17 open decision about unconditional release-build agreements, which our series adds in G18/G19/G21)? Show it with mpirun plus fault injection on one rank, pristine 7.0.18 vs our rebased series.

Final message: at most 15 lines per the brief, plus the WORK paths.
```

## Launch 7: bdgraph / vdgraph (G22, G23)

```
You are one of 8 agents re-auditing Scotch findings on the new 7.0.18 release for PyScotch. Read and follow /tmp/claude-0/-home-user-playground/925301e5-494b-5a33-b598-8eaa63dd5c1d/scratchpad/infra18/BRIEF18.md exactly (it has paths, setup, method and the strict output format). Then read INFRA/STYLE.md and sections 2-3 of INFRA/scotch_maint7.0.txt.

Your groups, in this order: G22-bdgraph, G23-vdgraph-dorder (items in INFRA/groups/<GROUP>.json). One WORK dir per group under WORKROOT. These two groups saw the most upstream change (17 commits), so take the time to do them thoroughly.

Group notes (PT-Scotch: mpirun --oversubscribe with 60 s timeouts, MPI_Init_thread(MPI_THREAD_MULTIPLE); per-rank malloc-failure shims exist in the 7.0.17 kits under PYS/upstream/repro/):
- G22: 219040c8 (bbalglbval/bbalval, shared with G13), 64883044 and d12fafc0 (compare partition quality on the ABSOLUTE value of the load imbalance), aa24a7cb (debug flag name), 23caa258 (proper array cells for error return codes and better clean-up on error).
- G23: 2d1b7e39 (vdgraphCheck tests local vertex partition loads), aace01bf (save and restore local vertex separation loads), 2ae72b81 and 6034c290 (absolute imbalance, the vdgraph twins of G22's), addcd163 (memory leak; check (almost) all outputs), 5b43f6d2 (remove a useless and bogus debug check), cc440aca (debug flag name), 59c9a31c (base the receive label array because the displacement array is based), 96a44b3d (sanity check in dmapSave), b260ba75 (negative return from dorderCblkDist on error, which is our patch taken verbatim: confirm and drop ours).
The absolute-imbalance commits change which partition wins, so they change OUTPUTS. Check that the sequential twins (bgraph/vgraph store/compare code) use the same rule, or say why not, and run the dgord/dgpart reference outputs before and after. For addcd163 ("check (almost) all outputs"), list which outputs are still unchecked. Build both trees with -DSCOTCH_DEBUG_ALL as well, because several of these commits touch debug-only code.

Final message: at most 15 lines per the brief, plus the WORK paths.
```

## Launch 8: tools / build / CI (G27-G30)

```
You are one of 8 agents re-auditing Scotch findings on the new 7.0.18 release for PyScotch. Read and follow /tmp/claude-0/-home-user-playground/925301e5-494b-5a33-b598-8eaa63dd5c1d/scratchpad/infra18/BRIEF18.md exactly (it has paths, setup, method and the strict output format). Then read INFRA/STYLE.md and sections 2-3 of INFRA/scotch_maint7.0.txt.

Your groups, in this order: G27-seq-tools, G28-tools-docs-tests, G29-cmake-sources-config, G30-cmake-tests-make-ci (items in INFRA/groups/<GROUP>.json). One WORK dir per group under WORKROOT.

Group notes:
- Upstream 7.0.18 commits on your files: 635741dd (parallel build with older Bison versions [report A. Lindsay]: Makefile dependency rules for parser files), 0d878bdd (new test for a three-level composite target architecture: check its Makefile and CMakeLists.txt twins agree), 7a5d07b3 (link PT-ESMUMPS with the PT-Scotch libraries: check the CMake twin and the Makefile), 49149c10 (typos in src/CMakeLists.txt), cf82942a (gscat usage message: check the man page twin), 97adde87 (CMake test names).
- Verify the build-system items by actually building. Make build: the ASan trees. CMake build: in a copy of INFRA/v7.0.18, both Gnum sizes, then ctest; a parallel `make -j` loop for race-type items, repeated several times. Note the 7.0.17 lesson: the library link rule used `$?`, so an incremental `make scotch` produced a .so missing most symbols (G30's first commit fixed this). Check whether 7.0.18 changed that.
- 0d878bdd and 635741dd also touch src/check and Makefiles that many other groups' patches add test lines to. Rebase G30's test-list patches carefully: they are the most conflict-prone in the combined series.
- G27 has no upstream source change; re-run the kits on 7.0.18, rebase, and move on.

Final message: at most 15 lines per the brief, plus the WORK paths.
```

## Messages sent to running agents

To the mesh/kgraph agent (G12), after G25 reported PS3-G25-1:

```
Forward from the G25 agent (for your G12 review of 22c9c42e): new PS3-G25-1 (high). 22c9c42e sizes the merge hash table in kgraph_map_rb.c from the fixed domains only; SCOTCH_graphMapFixed with one fixed vertex onto K32 hangs at kgraph_map_rb.c:430 on pristine 7.0.18. G25's fix is .../work18/G25-metis-graph-part/patches/0007-*.patch (read its repro in .../work18/G25-metis-graph-part/repro/). Please: (1) make sure your G12 audit entry for 22c9c42e reflects this (verdict incomplete/wrong as you judge), with related_ids PS3-G25-1; (2) do NOT write a second commit for the same hunk; if you already have one in G12, tell me which of the two is better and keep only that one (if yours, say so and I will drop G25's 0007 at merge); (3) check your G12 series and G25's 0007 apply together (G12 comes before G25 in the series order). Mention the outcome in your final message.
```

To the same agent, after G02 reported the same hang:

```
Update to my previous note: the G02 agent (finished) also found the 22c9c42e hang (SCOTCH_graphMapFixed with many more parts than fixed vertices, e.g. cmplt 64 with 2 fixed vertices; loop at kgraph_map_rb.c:428) and fixed it in .../work18/G02-arch-tleaf-hcub-build/patches/0008-*.patch, plus a hash-table leak on the 6f734966 error return in 0009. So there are now two candidate fixes (G02 0008, G25 0007) and possibly yours. Do not write another one. In your G12 audit for 22c9c42e/6f734966, record the verdict and related ids (PS3-G25-1 and G02's extra.json ids for these), and tell me in your final message which of G02 0008 / G25 0007 is the better fix (read both; check they fix the same root cause), and whether 0008/0009 should belong to G12 rather than G02 (my default: keep them in G02 and drop G25 0007). Also: PS3-G02-6 (out-of-range fixed parts also hang) touches the mapping API; note whether it is in your files.
```

Outcome: G12's 0002/0004 kept (regression test, more complete leak fix); G02 0008/0009 and G25 0007 dropped,
their findings repointed to G12's commits and their new-defect ids merged into PS3-G12-1/2.
